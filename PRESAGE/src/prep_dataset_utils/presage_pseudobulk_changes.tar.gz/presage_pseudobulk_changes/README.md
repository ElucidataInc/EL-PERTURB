# PRESAGE Pseudobulk Mode — Usage Guide

## Overview

These changes allow PRESAGE to train on pre-pseudobulked data without
losing single-cell-derived gene embedding quality.

**What's provided:**

1. **`prepare_presage_data.py`** — Full pipeline: SC h5ad → pseudobulk h5ad + DEGs + splits + embeddings
2. **Modified `datamodule_multicell.py`** — Accepts pre-pseudobulked input
3. **Modified `presage_context_embs.py`** — Loads pre-computed embeddings when available

## Step 1: Run the data preparation script

`prepare_presage_data.py` starts from your single-cell h5ad and does everything:
1. Loads and filters SC data (removes "excluded" cells, cleans columns)
2. Computes DEGs from SC data (per cell type, t-test, top 1000 genes)
3. Computes SC-derived gene embeddings (while SC data is still in memory)
4. Creates pseudobulked AnnData (mean per perturbation_group)
5. Saves the pseudobulk h5ad as PRESAGE dataset files
6. Generates train/test split files
7. Writes a metadata JSON with all paths + a config snippet

### Example: Direct split

```bash
python prepare_presage_data.py \
    --scdata_file /path/to/sc_data.h5ad \
    --split_col my_split \
    --target_name k562 \
    --target_key cell_type \
    --pert_key perturbation \
    --pert_group_key perturbation_group \
    --control_key non-targeting \
    --prior_type dp \
    --prior_by_group cell_type \
    --n_nmf_embedding 512 \
    --output_dir /path/to/prepared/ \
    --mode None
```

Uses the split column directly. Produces one split file (`seed_0.json`).

### Example: Target cell line K-fold CV

```bash
python prepare_presage_data.py \
    ... \
    --mode target_fold_5
```

K-fold splits the target cell line's training perts. Other cell lines'
training perts are added to every fold's train set. Produces 5 split files.

### Embedding control

`--prior_type` controls which embeddings are computed:

| `prior_type` | What it does |
|---|---|
| `dp` | Computes coexpression + transpose matrix embeddings (data-derived priors) |
| `kp` | Skips data-derived embeddings entirely (knowledge/pathway priors only — loaded from files at training time) |
| `all` | Computes data-derived AND expects knowledge priors at training time |

`--prior_by_group` (e.g. `cell_type`) computes separate embeddings per group.
This matches PRESAGE's `model.prior_by_group` config.

### Output structure

```
output_dir/
├── prepare_metadata.json                # All paths + PRESAGE config snippet
├── dataset/
│   ├── degs/
│   │   ├── k562:CHMP3.json
│   │   ├── ...
│   │   └── merged.degs.json
│   ├── ncells_per_perturbation.json     # Original SC cell counts
│   dataset.h5ad                         # PSEUDOBULK data (not SC!)
│   dataset_preprocessed.h5ad            # Same (PRESAGE convention)
├── splits/
│   ├── seed_0.json
│   └── ...
└── embeddings/
    ├── precomputed_coexpression_emb.pkl  # (absent if prior_type=kp)
    └── precomputed_transpose_matrix_emb.pkl
```

Note: `dataset.h5ad` contains the **pseudobulked** data (one row per
perturbation_group), not the original SC data. The SC data is only used
transiently during this prep step.

## Step 2: Configure and run PRESAGE

The metadata JSON includes a ready-to-use config snippet. The key settings:

```python
# Tell the datamodule this is pre-pseudobulked data
config["data.pre_pseudobulked"] = True

# Point to the pseudobulk dataset
config["data.dataset"] = "dataset"       # basename of the h5ad
config["data.data_dir"] = "/path/to/prepared/"

# Point to pre-computed SC embeddings (if prior_type is dp or all)
config["model.precomputed_coexpression_emb"] = "/path/to/prepared/embeddings/precomputed_coexpression_emb.pkl"
config["model.precomputed_transpose_matrix_emb"] = "/path/to/prepared/embeddings/precomputed_transpose_matrix_emb.pkl"

# Point split seed to the generated split files
config["data.seed"] = "/path/to/prepared/splits/seed_0.json"
```

The rest of the pipeline works as before.

## What changes under the hood

| Component | SC mode (original) | Pseudobulk mode |
|---|---|---|
| `scPerturbData.__init__` | `compute_pseudobulk()` aggregates SC rows | Skipped — data is already aggregated |
| `prepare_data()` | Downloads, preprocesses, computes DEGs | Expects preprocessed h5ad + pre-computed DEGs |
| Coexpression embeddings | PCA on (n_cells x n_genes) | Loaded from pre-computed pickle |
| Transpose matrix embeddings | PCA on per-pert averages | Loaded from pickle (or computed — identical result) |
| `compute_norms` (Evaluator) | SC covariance + null distribution | **Skipped** — ncells file set to "None" |
| All other metrics | Unchanged | Unchanged |

## Modified source files

- **`datamodule_multicell.py`** — `pre_pseudobulked` flag flows through `from_config` -> `scPerturbDataModule` -> `create_dataset` -> `scPerturbData`. Skips pseudobulk aggregation, SC preprocessing, and ncells computation when set.
- **`presage_context_embs.py`** — `get_embeddings_from_training_gex_new` checks for `config["precomputed_{emb_source}_emb"]` and loads from pickle instead of computing from adata.
- **No changes needed to:** `presage_datamodule.py`, `model_harness_scheduler.py`, `evaluator.py`, `train.py`

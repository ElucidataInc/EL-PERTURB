"""
PRESAGE Full Data Preparation Script (SC -> Pseudobulk)
======================================================

Starting from a single-cell AnnData, this script performs ALL prep steps:

  1. Load & filter SC data (remove excluded, clean columns)
  2. Compute DEGs from SC data (per cell type, t-test)
  3. Create pseudobulked AnnData (mean expression per perturbation_group)
  4. Save pseudobulk h5ad as the PRESAGE dataset files
  5. Generate train/test split files
  6. Pre-compute SC-derived gene embeddings (coexpression + transpose PCA)
  7. Save metadata JSON with all paths

After running this script, PRESAGE can train directly on pseudobulk data
using the `pre_pseudobulked=True` flag and the pre-computed embeddings.

Modes (--mode)
--------------
  None (default):
      Uses the split column directly. Train = split_col=="train",
      Test = split_col starts with "test_".
      Produces a single split file (seed_0.json).

  target_fold_N  (e.g. target_fold_5):
      Takes training perturbations from the target cell line only,
      splits them into N-fold CV. For each fold, other cell lines'
      training perts are added to the train set.
      Produces N split files (seed_0..N-1.json).

Embedding control (--prior_type)
--------------------------------
  dp   : Compute data-derived embeddings only (coexpression + transpose)
  kp   : Knowledge/pathway priors only -- NO data-derived embeddings computed
  all  : Compute both data-derived + knowledge/pathway embeddings

  When prior_type is "kp", embedding computation is skipped entirely since
  those embeddings come from external files (pathway_files in PRESAGE config).

Grouping (--prior_by_group)
---------------------------
  If set (e.g. "cell_type"), embeddings are computed separately per group.
  This matches PRESAGE's internal behavior when model.prior_by_group is set.

Usage:
    python prepare_presage_data.py \\
        --scdata_file /path/to/sc_data.h5ad \\
        --split_col my_split \\
        --target_name k562 \\
        --target_key cell_type \\
        --pert_key perturbation \\
        --pert_group_key perturbation_group \\
        --control_key non-targeting \\
        --prior_type dp \\
        --prior_by_group cell_type \\
        --n_nmf_embedding 512 \\
        --output_dir /path/to/prepared_data/ \\
        --mode target_fold_5
"""

import argparse
import json
import os
import pickle as pkl
import re

import numpy as np
import pandas as pd
import scanpy as sc
from sklearn.decomposition import PCA
from sklearn.model_selection import KFold
from tqdm import tqdm


# =========================================================================
# 1. DEG computation
# =========================================================================

def compute_degs_for_celltype(
    adata, deg_path, cell_type, cell_type_key, pert_key, pert_group_key, control_pert
):
    """Compute DEGs for a single cell type using SC data.

    Mirrors the logic from the PRESAGE HPO script: t-test with variance
    overestimation, ranked by absolute value, top 1000 genes per perturbation.
    Control cells are capped at 5000 to avoid memory issues.
    """
    sdata = adata[adata.obs[cell_type_key] == cell_type, :]

    vc = sdata.obs[pert_key].value_counts()
    if vc.get(control_pert, 0) > 5000:
        ctrl_sample = (
            sdata.obs[sdata.obs[pert_key] == control_pert]
            .sample(5000, random_state=0)
            .index.tolist()
        )
        pert_cells = sdata.obs[sdata.obs[pert_key] != control_pert].index.tolist()
        sdata = sdata[ctrl_sample + pert_cells, :].copy()

    degs = {}
    perts = set(sdata.obs.loc[sdata.obs[pert_key] != control_pert, pert_group_key])
    for pert in tqdm(perts, desc=f"DEGs [{cell_type}]"):
        target_file = os.path.join(deg_path, f"{pert}.json")

        if os.path.isfile(target_file):
            with open(target_file) as fp:
                degs[pert] = json.load(fp)
            continue

        temp = sdata[
            sdata.obs[pert_group_key].isin(
                [cell_type + ":" + control_pert, pert]
            ),
            :,
        ].copy()

        sc.tl.rank_genes_groups(
            temp,
            groupby=pert_group_key,
            reference=cell_type + ":" + control_pert,
            method="t-test_overestim_var",
            rankby_abs=True,
        )

        result = (
            pd.DataFrame(temp.uns["rank_genes_groups"]["names"])
            .loc[:999, pert]
            .to_list()
        )
        degs[pert] = result

        with open(target_file, "w") as fp:
            json.dump(result, fp)

    return degs


# =========================================================================
# 2. Pseudobulk computation
# =========================================================================

def compute_pseudobulk_adata(scdata, pert_group_key, target_key, pert_key, control_key):
    """Create a pseudobulked AnnData from SC data.

    Each row in the output is the mean expression for one perturbation_group.
    The .obs retains perturbation, perturbation_group, cell_type, and the
    split column. Control pseudobulk rows are created per cell type.

    Returns:
        pbulk_adata: AnnData with obs as pseudobulk samples
        ncells_per_pert: dict mapping perturbation_group -> number of SC cells
    """
    print("  Computing pseudobulk (mean per perturbation_group)...")

    # Track cell counts before aggregating
    ncells_per_pert = dict(scdata.obs[pert_group_key].value_counts())
    ncells_per_pert = {str(k): int(v) for k, v in ncells_per_pert.items()}

    # Group by perturbation_group and compute mean expression
    grouped = scdata.obs.groupby(pert_group_key)

    pbulk_X = []
    pbulk_obs_rows = []

    for group_name, group_df in tqdm(grouped, desc="  Pseudobulking"):
        cell_indices = group_df.index
        mean_expr = np.mean(scdata[cell_indices].X, axis=0)

        # Flatten if needed (sparse produces matrices)
        if hasattr(mean_expr, 'A1'):
            mean_expr = mean_expr.A1
        mean_expr = np.asarray(mean_expr).ravel()

        pbulk_X.append(mean_expr)

        # Get metadata from first cell in group (they share pert_group, cell_type, etc.)
        first_cell = group_df.iloc[0]
        obs_row = {
            pert_group_key: group_name,
            pert_key: first_cell[pert_key],
            target_key: first_cell[target_key],
        }
        # Carry over any other columns (like split columns)
        for col in group_df.columns:
            if col not in obs_row:
                obs_row[col] = first_cell[col]

        pbulk_obs_rows.append(obs_row)

    pbulk_X = np.array(pbulk_X, dtype=np.float32)
    pbulk_obs = pd.DataFrame(pbulk_obs_rows)
    pbulk_obs.index = pbulk_obs[pert_group_key].astype(str)

    pbulk_adata = sc.AnnData(
        X=pbulk_X,
        obs=pbulk_obs,
        var=scdata.var.copy(),
    )

    print(f"  Pseudobulk result: {pbulk_adata.shape[0]} samples x {pbulk_adata.shape[1]} genes")
    return pbulk_adata, ncells_per_pert


# =========================================================================
# 3. Embedding computation
# =========================================================================

def compute_coexpression_embedding(adata, n_components):
    """PCA on the (n_cells x n_genes) matrix -- captures gene co-expression."""
    size = list(adata.shape) + [n_components]
    n_comp = int(np.min(size))
    print(f"    Coexpression PCA: {adata.shape[0]} cells x {adata.shape[1]} genes -> {n_comp} components")

    X = adata.X
    if hasattr(X, 'toarray'):
        X = X.toarray()

    pc = PCA(n_components=n_comp).fit(X)
    emb = pc.components_.T
    emb = np.pad(
        emb,
        ((0, 0), (0, n_components - emb.shape[1])),
        "constant",
        constant_values=0,
    )
    return pd.DataFrame(emb, index=adata.var.index)


def compute_transpose_matrix_embedding(adata, pert_field, n_components):
    """Average cells per perturbation, then PCA on (n_perts x n_genes)."""
    X = adata.X
    if hasattr(X, 'toarray'):
        X = X.toarray()

    # Build perturbation-averaged matrix
    avg_perts = []
    for group_name, group_df in adata.obs.groupby(pert_field):
        idx = np.where(adata.obs.index.isin(group_df.index))[0]
        avg_perts.append((group_name, np.mean(X[idx], axis=0)))

    avg_mat = pd.DataFrame(
        np.array([ap[1] for ap in avg_perts]),
        index=[ap[0] for ap in avg_perts],
        columns=adata.var.index,
    )
    size = list(avg_mat.shape) + [n_components]
    n_comp = int(np.min(size))
    print(f"    Transpose PCA: {avg_mat.shape[0]} perturbations x {avg_mat.shape[1]} genes -> {n_comp} components")

    pc = PCA(n_components=n_comp).fit(avg_mat)
    emb = pc.components_.T
    emb = np.pad(
        emb,
        ((0, 0), (0, n_components - emb.shape[1])),
        "constant",
        constant_values=0,
    )
    return pd.DataFrame(emb, index=avg_mat.columns)


def compute_embeddings(train_adata, args):
    """Compute SC-derived gene embeddings, respecting prior_type and prior_by_group.
    
    Returns:
        coex_out: coexpression embeddings (DataFrame or dict of DataFrames, or None)
        transpose_out: transpose matrix embeddings (same, or None)
    """
    prior_type = args.prior_type
    prior_by_group = args.prior_by_group
    n_emb = args.n_nmf_embedding

    # prior_type == "kp" means only knowledge priors -- no data-derived embeddings
    if prior_type == "kp":
        print("  prior_type='kp': skipping data-derived embedding computation")
        print("  (Knowledge/pathway embeddings are loaded from files at training time)")
        return None, None

    print(f"  prior_type='{prior_type}': computing data-derived embeddings")

    is_grouped = (prior_by_group is not None and str(prior_by_group) != "None")

    if is_grouped:
        print(f"  Grouped by '{prior_by_group}'")
        groups = sorted(train_adata.obs[prior_by_group].unique().tolist())
        print(f"  Groups: {groups}")

        coex_dict = {}
        transpose_dict = {}
        for g in groups:
            print(f"\n  --- Group: {g} ---")
            adata_sub = train_adata[train_adata.obs[prior_by_group] == g, :]
            coex_dict[g] = compute_coexpression_embedding(adata_sub, n_emb)
            transpose_dict[g] = compute_transpose_matrix_embedding(
                adata_sub, args.pert_key, n_emb
            )
        return coex_dict, transpose_dict
    else:
        print("  Ungrouped: computing single set of embeddings")
        coex_out = compute_coexpression_embedding(train_adata, n_emb)
        transpose_out = compute_transpose_matrix_embedding(
            train_adata, args.pert_key, n_emb
        )
        return coex_out, transpose_out


# =========================================================================
# 4. Split generation
# =========================================================================

def parse_mode(mode_str):
    """Parse mode string. Returns (mode_type, n_folds)."""
    if mode_str is None or mode_str.lower() == "none":
        return ("direct", 1)

    match = re.match(r"target_fold_(\d+)", mode_str)
    if match:
        return ("target_fold", int(match.group(1)))

    raise ValueError(
        f"Unrecognized mode '{mode_str}'. "
        f"Expected None or 'target_fold_N' (e.g. target_fold_5)."
    )


def create_splits_direct(scdata, split_col, pert_group_key, splits_dir):
    """Mode=None: use the split column directly."""
    train_perts = (
        scdata.obs.loc[scdata.obs[split_col] == "train", pert_group_key]
        .unique().tolist()
    )
    test_perts = (
        scdata.obs.loc[scdata.obs[split_col].str.startswith("test_"), pert_group_key]
        .unique().tolist()
    )

    split = {
        "train": train_perts,
        "val": train_perts,
        "test": test_perts,
    }

    split_file = os.path.join(splits_dir, "seed_0.json")
    with open(split_file, "w") as f:
        json.dump(split, f)
    print(f"  Saved direct split -> {split_file}")
    print(f"    train: {len(train_perts)}, test: {len(test_perts)}")
    return 1


def create_splits_target_fold(
    scdata, split_col, target_name, target_key, pert_group_key, n_folds, splits_dir
):
    """Mode=target_fold_N: K-fold CV on target cell line training perts."""

    # Target cell line training perturbations -- these get split
    target_train_perts = (
        scdata.obs.loc[
            (scdata.obs[split_col] == "train")
            & (scdata.obs[target_key] == target_name),
            pert_group_key,
        ]
        .unique().tolist()
    )

    # Everything else (other cell types' perts + controls) always in train
    all_perts = scdata.obs[pert_group_key].unique().tolist()
    remaining_perts = list(set(all_perts) - set(target_train_perts))

    # Test perturbations
    test_perts = (
        scdata.obs.loc[scdata.obs[split_col].str.startswith("test_"), pert_group_key]
        .unique().tolist()
    )

    print(f"  Target '{target_name}' training perts to split: {len(target_train_perts)}")
    print(f"  Other perts always in train: {len(remaining_perts)}")
    print(f"  Test perts: {len(test_perts)}")

    kf = KFold(n_splits=n_folds, shuffle=True, random_state=42)
    for fold, (train_idx, val_idx) in enumerate(kf.split(target_train_perts)):
        fold_train = [target_train_perts[i] for i in train_idx]
        fold_val = [target_train_perts[i] for i in val_idx]
        fold_train_final = fold_train + remaining_perts

        split = {
            "train": fold_train_final,
            "val": fold_val,
            "test": test_perts,
        }

        split_file = os.path.join(splits_dir, f"seed_{fold}.json")
        with open(split_file, "w") as f:
            json.dump(split, f)
        print(f"  Fold {fold}: train={len(fold_train_final)} "
              f"(target={len(fold_train)} + other={len(remaining_perts)}), "
              f"val={len(fold_val)}")

    return n_folds


# =========================================================================
# Main pipeline
# =========================================================================

def main():
    parser = argparse.ArgumentParser(
        description="PRESAGE full data prep: SC -> pseudobulk + DEGs + splits + embeddings"
    )

    # Data arguments
    parser.add_argument("--scdata_file", type=str, required=True,
                        help="Path to single-cell AnnData h5ad file")
    parser.add_argument("--split_col", type=str, required=True,
                        help="Column in .obs with train/test split labels")
    parser.add_argument("--target_name", type=str, required=True,
                        help="Target cell type name (e.g. 'k562')")
    parser.add_argument("--target_key", type=str, default="cell_type",
                        help="Column in .obs for cell type identity")
    parser.add_argument("--pert_key", type=str, default="perturbation",
                        help="Column in .obs for perturbation identity")
    parser.add_argument("--pert_group_key", type=str, default="perturbation_group",
                        help="Column in .obs for perturbation_group (e.g. 'k562:CHMP3')")
    parser.add_argument("--control_key", type=str, default="non-targeting",
                        help="Value in pert_key that identifies control cells")

    # Embedding / prior arguments
    parser.add_argument("--prior_type", type=str, default="dp",
                        choices=["dp", "kp", "all"],
                        help="Which priors to compute. "
                             "dp=data-derived, kp=knowledge only (skip), all=both")
    parser.add_argument("--prior_by_group", type=str, default=None,
                        help="Column to group embeddings by (e.g. 'cell_type'). "
                             "If set, computes separate embeddings per group value.")
    parser.add_argument("--n_nmf_embedding", type=int, default=512,
                        help="Number of PCA components for gene embeddings")

    # Mode argument
    parser.add_argument("--mode", type=str, default=None,
                        help="Split mode. None = use split_col directly. "
                             "'target_fold_N' = N-fold CV on target cell line.")

    # Output
    parser.add_argument("--output_dir", type=str, required=True,
                        help="Root directory for all prepared outputs")

    args = parser.parse_args()

    mode_type, n_folds = parse_mode(args.mode)
    print(f"Mode: {mode_type}" + (f" ({n_folds} folds)" if mode_type == "target_fold" else ""))
    print(f"Prior type: {args.prior_type}")
    print(f"Prior by group: {args.prior_by_group}")

    # ---- Create output directories ----
    dataset_dir = os.path.join(args.output_dir, "dataset")
    deg_dir = os.path.join(dataset_dir, "degs")
    splits_dir = os.path.join(args.output_dir, "splits")
    emb_dir = os.path.join(args.output_dir, "embeddings")
    for d in [dataset_dir, deg_dir, splits_dir, emb_dir]:
        os.makedirs(d, exist_ok=True)

    # ==================================================================
    # Step 1: Load and filter SC data
    # ==================================================================
    print(f"\n{'='*60}")
    print("Step 1: Loading and filtering SC data")
    print(f"{'='*60}")

    scdata = sc.read_h5ad(args.scdata_file)
    print(f"  Raw: {scdata.shape[0]} cells, {scdata.shape[1]} genes")

    # Remove excluded cells
    if "excluded" in scdata.obs[args.split_col].values:
        scdata = scdata[~scdata.obs[args.split_col].isin(["excluded"]), :].copy()
        print(f"  After removing 'excluded': {scdata.shape[0]} cells")

    # Clean out other split columns
    cols_to_keep = [
        col for col in scdata.obs.columns
        if ("_stratified" not in col) and ("_random" not in col)
    ]
    if args.split_col not in cols_to_keep:
        cols_to_keep.append(args.split_col)
    cols_to_drop = list(scdata.obs.columns.difference(cols_to_keep))
    if cols_to_drop:
        scdata.obs.drop(columns=cols_to_drop, inplace=True)

    if hasattr(scdata.X, "toarray"):
        scdata.X = scdata.X.toarray()

    # ==================================================================
    # Step 2: Compute DEGs (from SC data, before pseudobulking)
    # ==================================================================
    print(f"\n{'='*60}")
    print("Step 2: Computing DEGs from SC data")
    print(f"{'='*60}")

    merged_deg_file = os.path.join(deg_dir, "merged.degs.json")
    if not os.path.exists(merged_deg_file):
        degs = {}
        for ct in scdata.obs[args.target_key].unique().tolist():
            print(f"\n  Cell type: {ct}")
            degs.update(
                compute_degs_for_celltype(
                    adata=scdata,
                    deg_path=deg_dir,
                    cell_type=ct,
                    cell_type_key=args.target_key,
                    pert_key=args.pert_key,
                    pert_group_key=args.pert_group_key,
                    control_pert=args.control_key,
                )
            )
        with open(merged_deg_file, "w") as fp:
            json.dump(degs, fp)
        print(f"\n  Saved merged DEGs ({len(degs)} perturbations) -> {merged_deg_file}")
    else:
        print(f"  Found existing DEGs at {merged_deg_file}")

    # ==================================================================
    # Step 3: Compute SC-derived gene embeddings (before pseudobulking)
    # ==================================================================
    print(f"\n{'='*60}")
    print("Step 3: Computing SC-derived gene embeddings")
    print(f"{'='*60}")

    # Filter to training cells + controls for embedding computation
    train_mask = scdata.obs[args.split_col] == "train"
    ctrl_mask = scdata.obs[args.pert_key] == args.control_key
    train_sc_adata = scdata[train_mask | ctrl_mask].copy()
    print(f"  Embedding input: {train_sc_adata.shape[0]} cells (train + control)")

    coex_out, transpose_out = compute_embeddings(train_sc_adata, args)

    coex_path = None
    transpose_path = None

    if coex_out is not None:
        coex_path = os.path.join(emb_dir, "precomputed_coexpression_emb.pkl")
        with open(coex_path, "wb") as f:
            pkl.dump(coex_out, f, protocol=pkl.HIGHEST_PROTOCOL)
        print(f"  Saved coexpression embeddings -> {coex_path}")

    if transpose_out is not None:
        transpose_path = os.path.join(emb_dir, "precomputed_transpose_matrix_emb.pkl")
        with open(transpose_path, "wb") as f:
            pkl.dump(transpose_out, f, protocol=pkl.HIGHEST_PROTOCOL)
        print(f"  Saved transpose matrix embeddings -> {transpose_path}")

    # Free memory before pseudobulking
    del train_sc_adata

    # ==================================================================
    # Step 4: Create pseudobulked AnnData
    # ==================================================================
    print(f"\n{'='*60}")
    print("Step 4: Creating pseudobulked AnnData")
    print(f"{'='*60}")

    pbulk_adata, ncells_per_pert = compute_pseudobulk_adata(
        scdata, args.pert_group_key, args.target_key, args.pert_key, args.control_key
    )

    # Save as PRESAGE dataset files (dataset.h5ad and dataset_preprocessed.h5ad)
    pbulk_h5ad_path = dataset_dir + ".h5ad"
    pbulk_preprocessed_path = dataset_dir + "_preprocessed.h5ad"

    if not os.path.exists(pbulk_h5ad_path):
        print(f"  Saving pseudobulk -> {pbulk_h5ad_path}")
        pbulk_adata.write_h5ad(pbulk_h5ad_path)
        pbulk_adata.write_h5ad(pbulk_preprocessed_path)
    else:
        print(f"  Found existing pseudobulk at {pbulk_h5ad_path}")

    # Save ncells_per_perturbation (useful if you later want compute_norms)
    ncells_path = os.path.join(dataset_dir, "ncells_per_perturbation.json")
    with open(ncells_path, "w") as f:
        json.dump(ncells_per_pert, f)
    print(f"  Saved cell counts -> {ncells_path}")

    # ==================================================================
    # Step 5: Generate train/test split files
    # ==================================================================
    print(f"\n{'='*60}")
    print("Step 5: Creating split files")
    print(f"{'='*60}")

    # Splits are based on the original SC data's perturbation_group labels
    if mode_type == "direct":
        num_splits = create_splits_direct(
            scdata, args.split_col, args.pert_group_key, splits_dir
        )
    elif mode_type == "target_fold":
        num_splits = create_splits_target_fold(
            scdata, args.split_col, args.target_name, args.target_key,
            args.pert_group_key, n_folds, splits_dir
        )

    # ==================================================================
    # Step 6: Save metadata
    # ==================================================================
    print(f"\n{'='*60}")
    print("Step 6: Saving metadata")
    print(f"{'='*60}")

    metadata = {
        "scdata_file": args.scdata_file,
        "split_col": args.split_col,
        "target_name": args.target_name,
        "target_key": args.target_key,
        "pert_key": args.pert_key,
        "pert_group_key": args.pert_group_key,
        "control_key": args.control_key,
        "prior_type": args.prior_type,
        "prior_by_group": args.prior_by_group,
        "n_nmf_embedding": args.n_nmf_embedding,
        "mode": args.mode,
        "mode_type": mode_type,
        "n_folds": n_folds,
        "num_splits": num_splits,
        "pseudobulk_shape": list(pbulk_adata.shape),
        "paths": {
            "dataset_dir": dataset_dir,
            "pseudobulk_h5ad": pbulk_h5ad_path,
            "pseudobulk_preprocessed_h5ad": pbulk_preprocessed_path,
            "ncells_per_perturbation": ncells_path,
            "deg_dir": deg_dir,
            "merged_degs": merged_deg_file,
            "splits_dir": splits_dir,
            "coexpression_emb": coex_path,
            "transpose_matrix_emb": transpose_path,
        },
        "presage_config_snippet": {
            "data.pre_pseudobulked": True,
            "data.dataset": os.path.basename(dataset_dir),
            "data.data_dir": os.path.dirname(dataset_dir),
            "model.precomputed_coexpression_emb": coex_path or "None",
            "model.precomputed_transpose_matrix_emb": transpose_path or "None",
            "model.prior_type": args.prior_type,
            "model.prior_by_group": args.prior_by_group or "None",
        },
    }

    metadata_path = os.path.join(args.output_dir, "prepare_metadata.json")
    with open(metadata_path, "w") as f:
        json.dump(metadata, f, indent=2)
    print(f"  Saved metadata -> {metadata_path}")

    # ==================================================================
    # Summary
    # ==================================================================
    print(f"\n{'='*60}")
    print("DONE -- All data preparation complete")
    print(f"{'='*60}")
    print(f"\n  Output directory:  {args.output_dir}")
    print(f"  Pseudobulk h5ad:   {pbulk_h5ad_path}  ({pbulk_adata.shape[0]} samples x {pbulk_adata.shape[1]} genes)")
    print(f"  DEGs:              {merged_deg_file}")
    print(f"  Splits:            {splits_dir}/  ({num_splits} file(s))")
    if coex_path:
        print(f"  Coexpression emb:  {coex_path}")
    if transpose_path:
        print(f"  Transpose emb:     {transpose_path}")
    if args.prior_type == "kp":
        print(f"  (No data-derived embeddings -- prior_type='kp')")
    print(f"  Cell counts:       {ncells_path}")
    print(f"  Metadata:          {metadata_path}")

    print(f"\n  To use with PRESAGE, set in your config:")
    print(f'    config["data.pre_pseudobulked"] = True')
    print(f'    config["data.dataset"] = "{os.path.basename(dataset_dir)}"')
    print(f'    config["data.data_dir"] = "{os.path.dirname(dataset_dir)}"')
    if coex_path:
        print(f'    config["model.precomputed_coexpression_emb"] = "{coex_path}"')
    if transpose_path:
        print(f'    config["model.precomputed_transpose_matrix_emb"] = "{transpose_path}"')
    print(f'    # Split seed files in: {splits_dir}/')


if __name__ == "__main__":
    main()

"""
PRESAGE Pre-computation Script for Pseudobulk Mode
===================================================

Reads the original single-cell AnnData, computes:
  1. DEGs (per cell type, using SC data)
  2. Train/test split files (PRESAGE-format JSON)
  3. SC-derived gene embeddings (coexpression + transpose matrix PCA)

All outputs are saved so that PRESAGE can subsequently run on a
pre-pseudobulked version of the same dataset.

Modes
-----
  --mode None (default):
      Uses the split column directly. Train = split_col=="train",
      Test = split_col starts with "test_".  Produces a single split file (seed_0.json).

  --mode target_fold_N  (e.g. target_fold_5):
      Takes the training perturbations from the target cell line only,
      splits them into N-fold CV.  For each fold, the held-out target perts
      become the val set; the remaining target perts PLUS all training perts
      from other cell lines go into train.  Produces N split files (seed_0..N-1.json).

Usage:
    python precompute_sc_embeddings.py \\
        --scdata_file /path/to/sc_data.h5ad \\
        --split_col my_split \\
        --target_name k562 \\
        --target_key cell_type \\
        --pert_key perturbation \\
        --pert_group_key perturbation_group \\
        --control_key non-targeting \\
        --n_nmf_embedding 512 \\
        --group_col cell_type \\
        --output_dir /path/to/precomputed/ \\
        --mode target_fold_5
"""

import argparse
import json
import os
import pickle as pkl
import re

import numpy as np
import pandas as pd
import scanpy as sc
from sklearn.decomposition import PCA
from sklearn.model_selection import KFold
from tqdm import tqdm


# =========================================================================
# DEG computation (mirrors compute_degs_for_celltype from HPO script)
# =========================================================================

def compute_degs_for_celltype(
    adata, deg_path, cell_type, cell_type_key, pert_key, pert_group_key, control_pert
):
    """Compute differentially expressed genes for a single cell type."""

    sdata = adata[adata.obs[cell_type_key] == cell_type, :]

    vc = sdata.obs[pert_key].value_counts()

    if vc.get(control_pert, 0) > 5000:
        ctrl_sample = (
            sdata.obs[sdata.obs[pert_key] == control_pert]
            .sample(5000, random_state=0)
            .index.tolist()
        )
        pert_cells = sdata.obs[sdata.obs[pert_key] != control_pert].index.tolist()
        sdata = sdata[ctrl_sample + pert_cells, :].copy()

    degs = {}
    perts = set(sdata.obs.loc[sdata.obs[pert_key] != control_pert][pert_group_key])
    for pert in tqdm(perts, desc=f"DEGs [{cell_type}]"):
        target = os.path.join(deg_path, f"{pert}.json")

        if os.path.isfile(target):
            with open(target) as fp:
                degs[pert] = json.load(fp)
                continue

        temp = sdata[
            sdata.obs[pert_group_key].isin(
                [cell_type + ":" + control_pert, pert]
            ),
            :,
        ].copy()
        sc.tl.rank_genes_groups(
            temp,
            groupby=pert_group_key,
            reference=cell_type + ":" + control_pert,
            method="t-test_overestim_var",
            rankby_abs=True,
        )

        result = (
            pd.DataFrame(temp.uns["rank_genes_groups"]["names"])
            .loc[:999, pert]
            .to_list()
        )
        degs[pert] = result

        with open(target, "w") as fp:
            json.dump(result, fp)

    return degs


# =========================================================================
# Embedding computation
# =========================================================================

def compute_coexpression_embedding(adata, n_components):
    """PCA on the (n_cells x n_genes) matrix — captures gene co-expression."""
    size = list(adata.shape) + [n_components]
    n_comp = int(np.min(size))
    print(f"  Coexpression PCA: {adata.shape[0]} cells x {adata.shape[1]} genes -> {n_comp} components")

    pc = PCA(n_components=n_comp).fit(adata.X)
    emb = pc.components_.T
    emb = np.pad(
        emb,
        ((0, 0), (0, n_components - emb.shape[1])),
        "constant",
        constant_values=0,
    )
    return pd.DataFrame(emb, index=adata.var.index)


def compute_transpose_matrix_embedding(adata, pert_field, n_components):
    """Average cells per perturbation, then PCA on (n_perts x n_genes) matrix."""
    avg_perts = [
        (tup[0], np.mean(adata[tup[1].index, :].X, axis=0))
        for tup in adata.obs.groupby(pert_field)
    ]
    avg_mat = pd.DataFrame(
        np.array([ap[1] for ap in avg_perts]),
        index=[ap[0] for ap in avg_perts],
        columns=adata.var.index,
    )
    size = list(avg_mat.shape) + [n_components]
    n_comp = int(np.min(size))
    print(f"  Transpose PCA: {avg_mat.shape[0]} perturbations x {avg_mat.shape[1]} genes -> {n_comp} components")

    pc = PCA(n_components=n_comp).fit(avg_mat)
    emb = pc.components_.T
    emb = np.pad(
        emb,
        ((0, 0), (0, n_components - emb.shape[1])),
        "constant",
        constant_values=0,
    )
    return pd.DataFrame(emb, index=avg_mat.columns)


# =========================================================================
# Split generation
# =========================================================================

def parse_mode(mode_str):
    """Parse mode string. Returns (mode_type, n_folds).
    
    mode_type is either 'direct' or 'target_fold'.
    n_folds is an int (only meaningful for target_fold).
    """
    if mode_str is None or mode_str.lower() == "none":
        return ("direct", 1)

    match = re.match(r"target_fold_(\d+)", mode_str)
    if match:
        return ("target_fold", int(match.group(1)))

    raise ValueError(
        f"Unrecognized mode '{mode_str}'. "
        f"Expected None or 'target_fold_N' (e.g. target_fold_5)."
    )


def create_splits_direct(scdata, split_col, pert_group_key, splits_dir):
    """Mode=None: use the split column directly for a single train/val/test split."""
    train_perts = (
        scdata.obs.loc[scdata.obs[split_col] == "train", pert_group_key]
        .unique()
        .tolist()
    )
    test_perts = (
        scdata.obs.loc[scdata.obs[split_col].str.startswith("test_"), pert_group_key]
        .unique()
        .tolist()
    )

    split = {
        "train": train_perts,
        "val": train_perts,   # PRESAGE convention: val == train when no separate val
        "test": test_perts,
    }

    split_file = os.path.join(splits_dir, "seed_0.json")
    with open(split_file, "w") as f:
        json.dump(split, f)
    print(f"  Saved direct split -> {split_file}")
    print(f"    train: {len(train_perts)} perturbations, test: {len(test_perts)} perturbations")

    return 1  # number of splits


def create_splits_target_fold(
    scdata, split_col, target_name, target_key, pert_group_key, n_folds, splits_dir
):
    """Mode=target_fold_N: K-fold CV on target cell line training perts,
    other cell lines' training perts always go in train."""

    # Target cell line training perturbations — these get split
    target_train_perts = (
        scdata.obs.loc[
            (scdata.obs[split_col] == "train")
            & (scdata.obs[target_key] == target_name),
            pert_group_key,
        ]
        .unique()
        .tolist()
    )

    # Everything else in the dataset (other cell types' train perts + controls)
    # that should always be in the train set
    all_perts = scdata.obs[pert_group_key].unique().tolist()
    remaining_perts = list(set(all_perts) - set(target_train_perts))

    # Also grab test perturbations for the test key in split files
    test_perts = (
        scdata.obs.loc[scdata.obs[split_col].str.startswith("test_"), pert_group_key]
        .unique()
        .tolist()
    )

    print(f"  Target '{target_name}' training perts to split: {len(target_train_perts)}")
    print(f"  Other perts always in train: {len(remaining_perts)}")
    print(f"  Test perts: {len(test_perts)}")

    kf = KFold(n_splits=n_folds, shuffle=True, random_state=42)
    for fold, (train_idx, val_idx) in enumerate(kf.split(target_train_perts)):
        fold_train = [target_train_perts[i] for i in train_idx]
        fold_val = [target_train_perts[i] for i in val_idx]

        # Add all other cell lines' training perts to the train set
        fold_train_final = fold_train + remaining_perts

        split = {
            "train": fold_train_final,
            "val": fold_val,
            "test": test_perts,
        }

        split_file = os.path.join(splits_dir, f"seed_{fold}.json")
        with open(split_file, "w") as f:
            json.dump(split, f)
        print(f"  Fold {fold}: train={len(fold_train_final)} (target={len(fold_train)} + other={len(remaining_perts)}), val={len(fold_val)}")

    return n_folds


# =========================================================================
# Main
# =========================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Pre-compute SC-derived artifacts for PRESAGE pseudobulk mode"
    )

    # Data arguments
    parser.add_argument("--scdata_file", type=str, required=True,
                        help="Path to single-cell AnnData h5ad file")
    parser.add_argument("--split_col", type=str, required=True,
                        help="Column in .obs with train/test split labels")
    parser.add_argument("--target_name", type=str, required=True,
                        help="Target cell type name (e.g. 'k562')")
    parser.add_argument("--target_key", type=str, default="cell_type",
                        help="Column in .obs for cell type identity")
    parser.add_argument("--pert_key", type=str, default="perturbation",
                        help="Column in .obs for perturbation identity")
    parser.add_argument("--pert_group_key", type=str, default="perturbation_group",
                        help="Column in .obs for perturbation_group (e.g. 'k562:CHMP3')")
    parser.add_argument("--control_key", type=str, default="non-targeting",
                        help="Value in pert_key that identifies control cells")

    # Embedding arguments
    parser.add_argument("--n_nmf_embedding", type=int, default=512,
                        help="Number of PCA components for embeddings")
    parser.add_argument("--group_col", type=str, default=None,
                        help="Column to group embeddings by (e.g. 'cell_type'). "
                             "If set, computes separate embeddings per group.")

    # Mode argument
    parser.add_argument("--mode", type=str, default=None,
                        help="Split mode. None = use split_col directly. "
                             "'target_fold_N' = N-fold CV on target cell line training perts.")

    # Output
    parser.add_argument("--output_dir", type=str, required=True,
                        help="Root directory for all precomputed outputs")

    args = parser.parse_args()

    mode_type, n_folds = parse_mode(args.mode)
    print(f"Mode: {mode_type}" + (f" ({n_folds} folds)" if mode_type == "target_fold" else ""))

    # ---- Create output directories ----
    dataset_dir = os.path.join(args.output_dir, "dataset")
    deg_dir = os.path.join(dataset_dir, "degs")
    splits_dir = os.path.join(args.output_dir, "splits")
    emb_dir = os.path.join(args.output_dir, "embeddings")
    for d in [dataset_dir, deg_dir, splits_dir, emb_dir]:
        os.makedirs(d, exist_ok=True)

    # ==================================================================
    # 1. Load SC data and filter
    # ==================================================================
    print(f"\n{'='*60}")
    print("Step 1: Loading and filtering SC data")
    print(f"{'='*60}")

    scdata = sc.read_h5ad(args.scdata_file)
    print(f"  Raw: {scdata.shape[0]} cells, {scdata.shape[1]} genes")

    # Remove excluded cells (same logic as prep_dataset_for_hpo)
    scdata = scdata[~scdata.obs[args.split_col].isin(["excluded"]), :].copy()
    print(f"  After removing 'excluded': {scdata.shape[0]} cells")

    # Clean out other split columns (keep the one we need)
    cols_to_keep = [
        col for col in scdata.obs.columns
        if ("_stratified" not in col) and ("_random" not in col)
    ]
    if args.split_col not in cols_to_keep:
        cols_to_keep.append(args.split_col)
    cols_to_drop = list(scdata.obs.columns.difference(cols_to_keep))
    if cols_to_drop:
        scdata.obs.drop(columns=cols_to_drop, inplace=True)

    if hasattr(scdata.X, "toarray"):
        scdata.X = scdata.X.toarray()

    # Save the filtered SC h5ad (PRESAGE expects dataset_path.h5ad and dataset_path_preprocessed.h5ad)
    sc_h5ad_path = os.path.join(dataset_dir + ".h5ad")
    sc_preprocessed_path = os.path.join(dataset_dir + "_preprocessed.h5ad")
    if not os.path.exists(sc_h5ad_path):
        print(f"  Saving filtered SC data -> {sc_h5ad_path}")
        scdata.write_h5ad(sc_h5ad_path)
        scdata.write_h5ad(sc_preprocessed_path)
    else:
        print(f"  Found existing SC data at {sc_h5ad_path}")

    # ==================================================================
    # 2. Compute DEGs
    # ==================================================================
    print(f"\n{'='*60}")
    print("Step 2: Computing DEGs")
    print(f"{'='*60}")

    merged_deg_file = os.path.join(deg_dir, "merged.degs.json")
    if not os.path.exists(merged_deg_file):
        degs = {}
        for ct in scdata.obs[args.target_key].unique().tolist():
            print(f"\n  Cell type: {ct}")
            degs.update(
                compute_degs_for_celltype(
                    adata=scdata,
                    deg_path=deg_dir,
                    cell_type=ct,
                    cell_type_key=args.target_key,
                    pert_key=args.pert_key,
                    pert_group_key=args.pert_group_key,
                    control_pert=args.control_key,
                )
            )
        with open(merged_deg_file, "w") as fp:
            json.dump(degs, fp)
        print(f"\n  Saved merged DEGs ({len(degs)} perturbations) -> {merged_deg_file}")
    else:
        print(f"  Found existing DEG file at {merged_deg_file}")

    # ==================================================================
    # 3. Create train/test split files
    # ==================================================================
    print(f"\n{'='*60}")
    print("Step 3: Creating split files")
    print(f"{'='*60}")

    if mode_type == "direct":
        num_splits = create_splits_direct(
            scdata, args.split_col, args.pert_group_key, splits_dir
        )
    elif mode_type == "target_fold":
        num_splits = create_splits_target_fold(
            scdata, args.split_col, args.target_name, args.target_key,
            args.pert_group_key, n_folds, splits_dir
        )

    # ==================================================================
    # 4. Compute SC-derived gene embeddings
    # ==================================================================
    print(f"\n{'='*60}")
    print("Step 4: Computing SC-derived gene embeddings")
    print(f"{'='*60}")

    # Filter to training cells + controls for embedding computation
    train_mask = scdata.obs[args.split_col] == "train"
    ctrl_mask = scdata.obs[args.pert_key] == args.control_key
    train_adata = scdata[train_mask | ctrl_mask].copy()
    print(f"  Embedding input: {train_adata.shape[0]} cells (train + control)")

    n_emb = args.n_nmf_embedding

    if args.group_col and args.group_col != "None":
        print(f"\n  Grouped mode: computing per-group embeddings by '{args.group_col}'")
        groups = sorted(train_adata.obs[args.group_col].unique().tolist())
        print(f"  Groups: {groups}")

        coex_dict = {}
        transpose_dict = {}
        for g in groups:
            print(f"\n  --- Group: {g} ---")
            adata_sub = train_adata[train_adata.obs[args.group_col] == g, :]
            coex_dict[g] = compute_coexpression_embedding(adata_sub, n_emb)
            transpose_dict[g] = compute_transpose_matrix_embedding(
                adata_sub, args.pert_key, n_emb
            )
        coex_out = coex_dict
        transpose_out = transpose_dict
    else:
        print("\n  Ungrouped mode: computing single set of embeddings")
        coex_out = compute_coexpression_embedding(train_adata, n_emb)
        transpose_out = compute_transpose_matrix_embedding(
            train_adata, args.pert_key, n_emb
        )

    coex_path = os.path.join(emb_dir, "precomputed_coexpression_emb.pkl")
    transpose_path = os.path.join(emb_dir, "precomputed_transpose_matrix_emb.pkl")

    with open(coex_path, "wb") as f:
        pkl.dump(coex_out, f, protocol=pkl.HIGHEST_PROTOCOL)
    print(f"\n  Saved coexpression embeddings -> {coex_path}")

    with open(transpose_path, "wb") as f:
        pkl.dump(transpose_out, f, protocol=pkl.HIGHEST_PROTOCOL)
    print(f"  Saved transpose matrix embeddings -> {transpose_path}")

    # ==================================================================
    # 5. Save metadata
    # ==================================================================
    metadata = {
        "scdata_file": args.scdata_file,
        "split_col": args.split_col,
        "target_name": args.target_name,
        "target_key": args.target_key,
        "pert_key": args.pert_key,
        "pert_group_key": args.pert_group_key,
        "control_key": args.control_key,
        "n_nmf_embedding": args.n_nmf_embedding,
        "group_col": args.group_col,
        "mode": args.mode,
        "mode_type": mode_type,
        "n_folds": n_folds,
        "num_splits": num_splits,
        "paths": {
            "dataset_dir": dataset_dir,
            "sc_h5ad": sc_h5ad_path,
            "sc_preprocessed_h5ad": sc_preprocessed_path,
            "deg_dir": deg_dir,
            "merged_degs": merged_deg_file,
            "splits_dir": splits_dir,
            "coexpression_emb": coex_path,
            "transpose_matrix_emb": transpose_path,
        },
    }

    metadata_path = os.path.join(args.output_dir, "precompute_metadata.json")
    with open(metadata_path, "w") as f:
        json.dump(metadata, f, indent=2)

    # ==================================================================
    # Summary
    # ==================================================================
    print(f"\n{'='*60}")
    print("DONE — All precomputed artifacts saved")
    print(f"{'='*60}")
    print(f"  Output dir:      {args.output_dir}")
    print(f"  Dataset h5ad:    {sc_h5ad_path}")
    print(f"  DEGs:            {merged_deg_file}")
    print(f"  Splits:          {splits_dir}/ ({num_splits} file(s))")
    print(f"  Embeddings:      {emb_dir}/")
    print(f"  Metadata:        {metadata_path}")
    print(f"\nTo use with PRESAGE pseudobulk mode, set in your config:")
    print(f'  config["data.pre_pseudobulked"] = True')
    print(f'  config["model.precomputed_coexpression_emb"] = "{coex_path}"')
    print(f'  config["model.precomputed_transpose_matrix_emb"] = "{transpose_path}"')
    print(f"  # Point data_dir and dataset to: {dataset_dir}")
    print(f"  # Point seed to split files in: {splits_dir}/")


if __name__ == "__main__":
    main()
